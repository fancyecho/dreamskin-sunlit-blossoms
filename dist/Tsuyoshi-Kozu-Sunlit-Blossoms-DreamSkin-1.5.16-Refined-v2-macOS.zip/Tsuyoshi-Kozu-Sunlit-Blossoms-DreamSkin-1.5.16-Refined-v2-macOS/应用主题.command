#!/bin/bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
ENGINE_ROOT="${HOME}/.codex/codex-dream-skin-studio"
THEME_ARCHIVE="${SCRIPT_DIR}/Tsuyoshi-Kozu-Sunlit-Blossoms.theme.zip"
THEME_ID="preset-tsuyoshi-kozu-sunlit-blossoms"

finish() {
  printf '\n按回车键关闭此窗口。'
  read -r _
}
trap finish EXIT

if [ ! -x "${ENGINE_ROOT}/scripts/import-theme-zip-macos.sh" ]; then
  printf '未找到已部署的 Dream Skin 1.5.16 引擎。\n' >&2
  printf '请先把本包内的“Codex Dream Skin.app”拖入“应用程序”，\n' >&2
  printf '右键打开后在菜单栏选择“修复引擎/重新安装引擎”。\n' >&2
  exit 1
fi

if [ ! -f "${THEME_ARCHIVE}" ]; then
  printf '主题 ZIP 缺失：%s\n' "${THEME_ARCHIVE}" >&2
  exit 1
fi

printf '正在验证并导入主题…\n'
"${ENGINE_ROOT}/scripts/import-theme-zip-macos.sh" --file "${THEME_ARCHIVE}"

printf '正在切换到精修主题…\n'
"${ENGINE_ROOT}/scripts/switch-theme-macos.sh" --id "${THEME_ID}"

printf '\n完成：Tsuyoshi Kozu · Sunlit White Blossoms 精修 v2 已导入并应用。\n'
